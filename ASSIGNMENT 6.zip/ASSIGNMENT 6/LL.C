

#include <stdio.h>
#include <stdlib.h>

/* ---------- Node structure ---------- */
struct Node {
    int data;
    struct Node *next;
};

struct Node *head = NULL;

/* ---------- Basic helper: create a node ---------- */
struct Node *createNode(int value) {
    struct Node *newNode = (struct Node *)malloc(sizeof(struct Node));
    newNode->data = value;
    newNode->next = NULL;
    return newNode;
}

/* ---------- Insert a value at the END of the list ---------- */
void insertAtEnd(int value) {
    struct Node *newNode = createNode(value);
    if (head == NULL) {
        head = newNode;
        return;
    }
    struct Node *temp = head;
    while (temp->next != NULL)
        temp = temp->next;
    temp->next = newNode;
}

/* ---------- Insert a value right AFTER a given node ---------- */
void insertAfterNode(struct Node *prevNode, int value) {
    if (prevNode == NULL) return;
    struct Node *newNode = createNode(value);
    newNode->next = prevNode->next;
    prevNode->next = newNode;
}

/* ---------- Traverse and print the list ---------- */
void traverse() {
    struct Node *temp = head;
    printf("{ ");
    while (temp != NULL) {
        printf("%d", temp->data);
        if (temp->next != NULL) printf(", ");
        temp = temp->next;
    }
    printf(" }\n");
}

/* ---------- Delete the node with the LARGEST value ---------- */
void deleteLargest() {
    if (head == NULL) return;

    /* find the largest value first */
    struct Node *temp = head;
    int maxVal = temp->data;
    while (temp != NULL) {
        if (temp->data > maxVal)
            maxVal = temp->data;
        temp = temp->next;
    }

    /* delete the first node that matches maxVal */
    if (head->data == maxVal) {
        struct Node *toDelete = head;
        head = head->next;
        free(toDelete);
        return;
    }
    struct Node *prev = head;
    struct Node *curr = head->next;
    while (curr != NULL) {
        if (curr->data == maxVal) {
            prev->next = curr->next;
            free(curr);
            return;
        }
        prev = curr;
        curr = curr->next;
    }
}

/* ---------- Delete the node with the SMALLEST value ---------- */
void deleteSmallest() {
    if (head == NULL) return;

    struct Node *temp = head;
    int minVal = temp->data;
    while (temp != NULL) {
        if (temp->data < minVal)
            minVal = temp->data;
        temp = temp->next;
    }

    if (head->data == minVal) {
        struct Node *toDelete = head;
        head = head->next;
        free(toDelete);
        return;
    }
    struct Node *prev = head;
    struct Node *curr = head->next;
    while (curr != NULL) {
        if (curr->data == minVal) {
            prev->next = curr->next;
            free(curr);
            return;
        }
        prev = curr;
        curr = curr->next;
    }
}

/* ---------- Delete the FIRST element ---------- */
void deleteFirst() {
    if (head == NULL) return;
    struct Node *toDelete = head;
    head = head->next;
    free(toDelete);
}

/* ---------- Delete the LAST element ---------- */
void deleteLast() {
    if (head == NULL) return;
    if (head->next == NULL) {
        free(head);
        head = NULL;
        return;
    }
    struct Node *prev = head;
    struct Node *curr = head->next;
    while (curr->next != NULL) {
        prev = curr;
        curr = curr->next;
    }
    prev->next = NULL;
    free(curr);
}

/* ---------- Main ---------- */
int main() {
    char misStr[50];
    int count[10] = {0};                 /* how many times digit d has appeared */
    struct Node *firstOccurrence[10] = {NULL}; /* node pointer of 1st occurrence of digit d */

    printf("Enter your MIS number: ");
    scanf("%s", misStr);

    printf("\n--- Building the linked list digit by digit ---\n");

    for (int i = 0; misStr[i] != '\0'; i++) {
        int digit = misStr[i] - '0';   /* convert char to int */
        count[digit]++;

        if (count[digit] == 1) {
            /* 1st occurrence -> insert digit at end */
            insertAtEnd(digit);

            /* remember which node this was, for possible 3rd occurrence later */
            struct Node *temp = head;
            while (temp->next != NULL) temp = temp->next;
            firstOccurrence[digit] = temp;

            printf("%d (1st time) -> insert %d at end       : ", digit, digit);
        }
        else if (count[digit] == 2) {
            /* 2nd occurrence -> insert digit*10 at end */
            int newVal = digit * 10;
            insertAtEnd(newVal);
            printf("%d (2nd time) -> insert %d at end       : ", digit, newVal);
        }
        else if (count[digit] == 3) {
            /* 3rd occurrence -> insert digit*100 right after the 1st occurrence node */
            int newVal = digit * 100;
            insertAfterNode(firstOccurrence[digit], newVal);
            printf("%d (3rd time) -> insert %d after its 1st occurrence: ", digit, newVal);
        }
        else {
            /* occurs more than 3 times - assignment doesn't define this,
               so we just skip / ignore further occurrences */
            printf("%d (occurred more than 3 times) -> ignored : ", digit);
        }

        traverse();
    }

    printf("\n--- Final list after all insertions ---\n");
    traverse();

    printf("\n--- Deletion operations ---\n");

    deleteLargest();
    printf("After deleting the largest number : ");
    traverse();

    deleteSmallest();
    printf("After deleting the smallest number : ");
    traverse();

    deleteFirst();
    printf("After deleting the first element   : ");
    traverse();

    deleteLast();
    printf("After deleting the last element    : ");
    traverse();

    return 0;
}